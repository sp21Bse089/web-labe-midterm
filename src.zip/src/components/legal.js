import React from 'react'
import Terms from './terms'
import Privacy from './privacy'

export default function Legal() {
  return (
    <div>
        <Terms/>
        <Privacy/>
    </div>
  )
}
